#ifndef UXM_RUNTIME_V16_IMPL_STUBS_BAS
#define UXM_RUNTIME_V16_IMPL_STUBS_BAS

' Minimal V16 helpers (geçici stub/implementation)
' Bu dosya derlemeyi ilerletmek için basit, doğru imzalı fonksiyonlar sağlar.

Function V16ReadSigned(ByVal idx As LongInt) As LongInt
    Return StatReadSigned(idx)
End Function

Function V16ValidRange(ByVal baseIndex As LongInt, ByVal countValue As LongInt) As Long
    Return StatValidRange(baseIndex, countValue)
End Function

Function V16Mean(ByVal baseIndex As LongInt, ByVal countValue As LongInt) As Double
    ' StatMeanScaled returns scaled integer; convert to unscaled double
    Return CDbl(StatMeanScaled(baseIndex, countValue)) / 1000000.0
End Function

Function V16VarianceSample(ByVal baseIndex As LongInt, ByVal countValue As LongInt) As Double
    ' StatVarianceScaled returns scaled integer; convert to unscaled double
    Return CDbl(StatVarianceScaled(baseIndex, countValue)) / 1000000.0
End Function

Sub V16WriteResultScaled(ByVal value As Double)
    Dim scaled As LongInt = CLngInt(value * 1000000.0)
    SetResult FromSignedValue(scaled)
    SetLogicFlags ResultValue()
    SetStatus STATUS_OK
End Sub

Sub V16WriteResultRaw(ByVal value As LongInt)
    SetResult CULngInt(value)
    SetStatus STATUS_OK
End Sub

Function V16AI(ByVal code As LongInt) As Long
    ' Placeholder wrapper for AI dispatch; return 0 (not handled) for now
    Return 0
End Function

#endif
